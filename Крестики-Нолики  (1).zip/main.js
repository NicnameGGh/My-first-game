const board = document.getElementById('board');
const status = document.getElementById('status');
const restartButton = document.getElementById('restartButton');

const X_CLASS = 'x';
const O_CLASS = 'o';
let currentPlayerClass = X_CLASS;

const WINNING_COMBINATIONS = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

let gameActive = true;
let boardState = ['', '', '', '', '', '', '', '', ''];

function handleCellClick(event) {
  const cell = event.target;
  const cellIndex = parseInt(cell.getAttribute('data-cell-index'));
  
  if (boardState[cellIndex] !== '' || !gameActive) {
    return;
  }
  
  placeMark(cell, cellIndex);
  if (checkWin()) {
    endGame(false);
  } else if (isBoardFull()) {
    endGame(true);
  } else {
    swapTurns();
  }
}

function placeMark(cell, cellIndex) {
  
  cell.classList.add(currentPlayerClass);
  boardState[cellIndex] = currentPlayerClass;
  playSound('mark');
}

function swapTurns() {
  currentPlayerClass = currentPlayerClass === X_CLASS ? O_CLASS : X_CLASS;
  status.innerText = `Ход игрока ${currentPlayerClass.toUpperCase()}`;
}

function checkWin() {
  return WINNING_COMBINATIONS.some(combination => {
    return combination.every(index => {
      return boardState[index] === currentPlayerClass;
    });
  });
}

function isBoardFull() {
  return boardState.every(cell => {
    return cell !== '';
  });
}

function endGame(draw) {
  if (draw) {
    status.innerText = 'Ничья!';
  } else {
    status.innerText = `Победил игрок ${currentPlayerClass.toUpperCase()}!`;
    playSound('end');
  }
  gameActive = false;
}

function startGame() {
  boardState = ['', '', '', '', '', '', '', '', ''];
  gameActive = true;
  currentPlayerClass = X_CLASS;
  status.innerText = `Ход игрока ${currentPlayerClass.toUpperCase()}`;
  board.innerHTML = '';
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell');
    cell.setAttribute('data-cell-index', i);
    cell.addEventListener('click', handleCellClick);
    board.appendChild(cell);
  }
}

function playSound(type) {
  const audio = new Audio();
  if (type === 'mark') {
    audio.src = 'sounds/mark.mp3';
  } else if (type === 'end') {
    audio.src = 'sounds/end.mp3';
  }
  audio.play();
}

restartButton.addEventListener('click', startGame);

startGame();